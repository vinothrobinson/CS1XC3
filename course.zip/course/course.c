/**
 * @file course.c
 * @author Vinoth Robinson (robinv4)
 * @brief The functions in this file are used to enroll students into courses,
 *        print information on the course, identify the top student, and also
 *        identify who is passing the course. 
 * @version 0.1
 * @date 2022-04-08
 * 
 * @copyright Copyright (c) 2022
 * 
 */

#include <stdlib.h>
#include <stdio.h>
#include "course.h"

/**
 * @brief This function enrolls students into a course and updates
 *        the value of the total students in that course. It uses
 *        calloc to add one student, and uses realloc to adjust the
 *        total number of students in that specific course.
 * 
 * @param course This parameter indicates the course that was chosen
 * @param student This parameter indicates the student that was chosen
 * @return void
 */
void enroll_student(Course *course, Student *student)
{
  course->total_students++;
  if (course->total_students == 1) 
  {
    course->students = calloc(1, sizeof(Student));
  }
  else 
  {
    course->students = 
      realloc(course->students, course->total_students * sizeof(Student)); 
  }
  course->students[course->total_students - 1] = *student;
}

/**
 * @brief The print_course function takes a course as the input and
 *        prints the course name, course code, total number of students
 *        and information regarding the students using the print_student
 *        function
 * 
 * @param course This parameter indicates the course that was chosen
 * @return void
 */
void print_course(Course* course)
{
  printf("Name: %s\n", course->name);
  printf("Code: %s\n", course->code);
  printf("Total students: %d\n\n", course->total_students);
  printf("****************************************\n\n");
  for (int i = 0; i < course->total_students; i++) 
    print_student(&course->students[i]);
}

/**
 * @brief The top_student function is desgined to find the student
 *        with the highest average. It uses a for loop to iterate
 *        through the list of students, and uses if statements to
 *        check if the current student has a greater average than
 *        the previous student with the highest average.
 * 
 * @param course This parameter indicates the course that was chosen
 * @return Student* The function returns the student who has the 
 *                  highest average
 */
Student* top_student(Course* course)
{
  if (course->total_students == 0) return NULL;
 
  double student_average = 0;
  double max_average = average(&course->students[0]);
  Student *student = &course->students[0];
 
  for (int i = 1; i < course->total_students; i++)
  {
    student_average = average(&course->students[i]);
    if (student_average > max_average) 
    {
      max_average = student_average;
      student = &course->students[i];
    }   
  }

  return student;
}

/**
 * @brief The passing function checks the averages of all the students
 *        in the course and returns the names of the students who have
 *        passed (must have an average greater than or equal to 50 to 
 *        pass). 
 * 
 *        For loops are used to determine the number of students who have
 *        passed the course, the first for loop is used to allocate the size 
 *        of the passing pointer variable, and the second is used to assign
 *        the values to this variable.
 * 
 * @param course This parameter indicates the course that was chosen
 * @param total_passing This parameter indicates how many students 
 *                      have passed
 * @return Student* The function returns the names of the students
 *                  who have passed the course including all information
 *                  associated to the student.
 */
Student *passing(Course* course, int *total_passing)
{
  int count = 0;
  Student *passing = NULL;
  
  for (int i = 0; i < course->total_students; i++) 
    if (average(&course->students[i]) >= 50) count++;
  
  passing = calloc(count, sizeof(Student));

  int j = 0;
  for (int i = 0; i < course->total_students; i++)
  {
    if (average(&course->students[i]) >= 50)
    {
      passing[j] = course->students[i];
      j++; 
    }
  }

  *total_passing = count;

  return passing;
}