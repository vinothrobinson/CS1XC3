/**
 * @file student.h
 * @author Vinoth Robinson (robinv4)
 * @brief This file contains the typedef struct for the Student type as well as
 *        the definitions for the functions used in the student.c file
 * @version 0.1
 * @date 2022-04-08
 * 
 * @copyright Copyright (c) 2022
 * 
 */

/**
 * @brief This is the Student type, it stores the first name and last name of 
 *        students, their stuednt id, and their grades
 * 
 */
typedef struct _student 
{ 
  char first_name[50]; /**< This is the student's first name */
  char last_name[50]; /**< This is the student's last name */
  char id[11]; /**< This is the student's id */
  double *grades; /**< This is the student's grades */
  int num_grades; /**< This is the number of grades a student has received */
} Student;

void add_grade(Student *student, double grade);
double average(Student *student);
void print_student(Student *student);
Student* generate_random_student(int grades); 
