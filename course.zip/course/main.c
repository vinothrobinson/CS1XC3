/**
 * @mainpage Courses and Students
 * 
 * The functions located in this folder are used to keep track of information
 * related to both courses and students. 
 * 
 * @file main.c
 * @author Vinoth Robinson (robinv4)
 * @brief This file will assign students to a course and determine who the
 *        top student are and which students have passed the course.
 * @version 0.1
 * @date 2022-04-08
 * 
 * @copyright Copyright (c) 2022
 * 
 */
#include <stdlib.h> 
#include <stdio.h>
#include <string.h>
#include "time.h"
#include "course.h"

/**
 * @brief This function will first create a course that students can be enrolled
 *        into. It uses the generate_random_student and enroll_student functions
 *        in order to do this. Then it will print out the information on the course
 *        using the print_course function. After that, the function will determine
 *        who the top student is using the top_student function, and then determine
 *        which students passed the course using the passing function.
 * 
 * @return int This function returns 0 since nothing is being returned due to all the
 *             values being printed. Its similar to the return type being void for a function,
 *             essentially nothing is returned.
 */
int main()
{
  srand((unsigned) time(NULL));

  Course *MATH101 = calloc(1, sizeof(Course));
  strcpy(MATH101->name, "Basics of Mathematics");
  strcpy(MATH101->code, "MATH 101");
  // Assigns students to the course associated with the code "MATH101"
  for (int i = 0; i < 20; i++) 
    enroll_student(MATH101, generate_random_student(8));

  // Print all the students in the course
  print_course(MATH101);

  // Prints which student is the top student
  Student *student;
  student = top_student(MATH101);
  printf("\n\nTop student: \n\n");
  print_student(student);

  // Iterates through passing to print out the students who have passed
  int total_passing;
  Student *passing_students = passing(MATH101, &total_passing);
  printf("\nTotal passing: %d\n", total_passing);
  printf("\nPassing students:\n\n");
  for (int i = 0; i < total_passing; i++) print_student(&passing_students[i]);
  
  return 0;
}