/**
 * @file course.h
 * @author Vinoth Robinson (robinv4)
 * @brief This file contains the typedef struct for Course and the
 *         definitions of the functions used in course.c
 * @version 0.1
 * @date 2022-04-08
 * 
 * @copyright Copyright (c) 2022
 * 
 */
#include "student.h"
#include <stdbool.h>

/**
 * @brief This is the Course type, it stores the course name, course
 *        code, the students in that course, and the total number of
 *        students in that course
 * 
 */
typedef struct _course 
{
  char name[100]; /**< The course name */
  char code[10]; /**< The course code */
  Student *students; /**< The students in the course*/
  int total_students; /**< The total number of students in the course*/
} Course;

void enroll_student(Course *course, Student *student);
void print_course(Course *course);
Student *top_student(Course* course);
Student *passing(Course* course, int *total_passing);


